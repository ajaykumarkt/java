// and or logic
import java.util.*;
public class Gates{
	public static void main(String[] args){
	Scanner x = new Scanner(System.in);
	int n = x.nextInt();
	int m = x.nextInt();
	int z = n^m;
	int w = (n&m)<<1;
	System.out.println(z+w);
	
}
}
