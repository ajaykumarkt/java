import java.util.Scanner;
import java.io.*;
public class Hello{
	public static void main(String arg[]) throws Exception
	{
		System.out.print("Enter two numbers: ");
		Double x,y;
		Scanner in = new Scanner(System.in);
		x = in.nextDouble();
		y = in.nextDouble();
		System.out.print("Enter an operator(+,-,/,*): ");
		String op = in.next();
		
		switch(op)
	{
		case "+":System.out.println(x +"+" + y +" = "+(x+y));
			break;
		case "-":System.out.println(x +"-"+ y +" = "+(x-y));
			break;
		case "/":System.out.println(x +"/"+ y +" = "+(x/y));
			break;
		case "*":System.out.println(x +"*"+ y +" = "+(x*y));
			break;
		default: break;
	}				
	}
}
