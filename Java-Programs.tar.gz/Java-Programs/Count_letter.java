// program to count number of letters,number and non letters

import java.io.*;
public class Count_letter{
	public static void main(String[] args) throws Exception{
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader bu = new BufferedReader(in);
	String str = bu.readLine();
	int count=0,num=0,nonletter=0;
	int n = str.length();
	for(int i = 0;i<n;i++){
	if(Character.isLetter(str.charAt(i)))
	{
		count++;

	}
	else if(Character.isDigit(str.charAt(i)))
	{num++;}
	else
	nonletter++;
	}
	
	System.out.println(count);
	System.out.println(num);
	System.out.println(nonletter);
	}
}
	
