//finding maximum path in inverted traingle
import java.util.*;

public class InvertedT{

	public static void main(String[] args)
	{
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		//System.out.println(n);
		int tria[n][n];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				tria[i][j] = sc.nextInt();		
			
			}
		}		
	}
}
