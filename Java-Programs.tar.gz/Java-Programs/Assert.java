// assert
import java.util.*;


public class Assert{
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	int age = sc.nextInt();
	assert age>=18:"not found";
	System.out.println("valid");
	}
}
