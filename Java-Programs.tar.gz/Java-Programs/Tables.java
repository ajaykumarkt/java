// table of given number upto 10
import java.util.*;
import java.io.*;
public class Tables{

	static void tables(int n){
		for(int i=1;i<=10;i++)
		System.out.println(n +" * "+i+" = "+(n*i));
	}

	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter a Number: ");
	int n = sc.nextInt();
	tables(n);
	}
}
	
