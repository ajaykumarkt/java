//decimal to binary

import java.util.Scanner;
public class DecimaltoBinary{
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	int d = sc.nextInt();
	int arr[] = new int[10];
	int i=0;
	while(d!=0){
		if(d%2==0){
		arr[i]=0;
		i++;}
		else{
		arr[i]=1;
		i++;}
	d=d/2;			
	}
	for(int k=i-1;k>=0;k--){
	System.out.print(arr[k]);	

	}
	System.out.println();
	}
}

