// overloading of main method
public class Ex1{
	public static void main(String[] args){
	System.out.println("Main One:");
	Ex1.main(5);
	}
	public static void main(int x){
	System.out.println("not in main"+x);
	}
}
