//Exception problems

public class Exception{
	public static void main(String[] args){
	System.out.println("Exception Handling");
	int a=7,b=1;
	try{
		int c=a/b;
		System.out.println(c);
	}
	catch(ArithmeticException e){
	System.out.println("Divide by Zero");		
	}
	
	}
}
