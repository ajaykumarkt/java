public class Overloading{
	public void sum(int x,int y)
	{
		System.out.println(x+y);
	}
	public void sum(double x,double y)
	{
		System.out.println(x+y);
	}
	public void sum(int x,int y,int z)
	{
		System.out.println(x+y+z);
	}
	public static void main(String[] args){
	Overloading obj = new Overloading();
	obj.sum(4,5.9);
	}
}	
