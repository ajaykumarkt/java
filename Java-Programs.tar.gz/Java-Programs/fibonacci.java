//finonacci series

public class Fibonacci{
